def adjust_predictions(predictions, scale_factor=1.3):
    return predictions * scale_factor